import React from 'react';
import { Page } from '../types';

interface SideNavBarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const NavButton: React.FC<{
  icon: string;
  isActive: boolean;
  onClick: () => void;
  label: string;
}> = ({ icon, isActive, onClick, label }) => {
  return (
    <button 
        onClick={onClick}
        aria-label={label}
        className={`flex items-center w-full p-4 rounded-lg transition-all duration-200 ${
            isActive ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'text-zinc-400 hover:bg-zinc-800 hover:text-white'
        }`}
    >
        <i className={`fas ${icon} w-8 text-xl`}></i>
        <span className="font-semibold">{label}</span>
    </button>
  );
};

const SideNavBar: React.FC<SideNavBarProps> = ({ currentPage, onNavigate }) => {
  return (
    <nav className="w-64 bg-[#1C1C1E] p-4 flex-col h-screen hidden lg:flex shrink-0">
      <div className="flex items-center gap-3 p-4 mb-8">
        <div className="w-12 h-12 p-1 bg-zinc-800 rounded-lg flex items-center justify-center">
            <img src="https://i.ibb.co/vvrSRLvz/Eran-logo-l.png" alt="Eran Studio Logo" className="w-full h-full object-contain"/>
        </div>
        <h1 className="text-xl font-bold text-white">Eran Studio</h1>
      </div>
      <div className="flex flex-col gap-2">
        <NavButton
          icon="fa-home"
          label="Home"
          isActive={currentPage === Page.Home}
          onClick={() => onNavigate(Page.Home)}
        />
        <NavButton
          icon="fa-briefcase"
          label="Services"
          isActive={currentPage === Page.Services}
          onClick={() => onNavigate(Page.Services)}
        />
        <NavButton
          icon="fa-info-circle"
          label="About"
          isActive={currentPage === Page.About}
          onClick={() => onNavigate(Page.About)}
        />
        <NavButton
          icon="fab fa-whatsapp"
          label="Contact"
          isActive={false}
          onClick={() => window.open('https://wa.me/265997761194', '_blank')}
        />
      </div>
    </nav>
  );
};

export default SideNavBar;
