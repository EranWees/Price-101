import React, { useState } from 'react';
import { Page, Device } from '../types';

interface DashboardProps {
  onNavigate: (page: Page) => void;
}

const initialDevices: Device[] = [
    { id: '1', name: 'Smart Light', details: '4 Lamps', icon: 'fa-lightbulb', on: true, page: Page.SmartLight },
    { id: '2', name: 'Smart AC', details: '2 Device', icon: 'fa-fan', on: false, page: Page.Dashboard }, // Not implemented
    { id: '3', name: 'Smart TV', details: '1 Device', icon: 'fa-tv', on: false, page: Page.Dashboard }, // Not implemented
    { id: '4', name: 'Smart Speaker', details: '2 Device', icon: 'fa-volume-high', on: false, page: Page.Dashboard }, // Not implemented
];

const DeviceCard: React.FC<{ device: Device; onToggle: (id: string) => void; onNavigate: (page: Page) => void }> = ({ device, onToggle, onNavigate }) => {
    const isClickable = device.page !== Page.Dashboard;
    return (
        <div 
            onClick={() => isClickable && onNavigate(device.page)}
            className={`rounded-3xl p-4 flex flex-col justify-between h-36 cursor-pointer transition-colors ${device.on ? 'bg-black text-white' : 'bg-zinc-100 text-black'}`}
        >
            <div className="flex justify-between items-start">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${device.on ? 'bg-zinc-700' : 'bg-white'}`}>
                    <i className={`fas ${device.icon} ${device.on ? 'text-white' : 'text-black'}`}></i>
                </div>
                 <div 
                    onClick={(e) => { e.stopPropagation(); onToggle(device.id); }}
                    className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${device.on ? 'bg-zinc-700' : 'bg-zinc-200'}`}
                 >
                    <div className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-white transition-transform ${device.on ? 'translate-x-6' : 'translate-x-1'}`}></div>
                </div>
            </div>
            <div>
                <p className="font-bold text-md">{device.name}</p>
                <p className={`text-sm ${device.on ? 'text-zinc-400' : 'text-zinc-500'}`}>{device.details}</p>
            </div>
        </div>
    );
};

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
    const [devices, setDevices] = useState<Device[]>(initialDevices);

    const handleToggle = (id: string) => {
        setDevices(prev => prev.map(d => d.id === id ? {...d, on: !d.on} : d));
    };

  return (
    <div className="p-6 pb-24">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Hello, Rocky</h1>
        </div>
        <div className="relative">
          <i className="fas fa-bell text-2xl"></i>
          <div className="absolute top-0 right-0 w-2 h-2 bg-blue-500 rounded-full"></div>
        </div>
      </header>
      
      <div className="bg-black text-white rounded-3xl p-5 mb-6">
        <div className="flex justify-between items-start mb-2">
            <div>
                <p className="text-4xl font-bold">18°C</p>
                <p className="text-zinc-400">Tue, February 07</p>
            </div>
            <div className="flex items-center">
                 <i className="fas fa-cloud-sun text-4xl text-blue-400"></i>
            </div>
        </div>
        <p className="font-semibold text-lg mb-4">Cloudy</p>
        <div className="flex justify-between text-center text-sm border-t border-zinc-700 pt-4">
            <div>
                <p className="font-bold">23°C</p>
                <p className="text-zinc-400">Indoor temp</p>
            </div>
            <div>
                <p className="font-bold">40%</p>
                <p className="text-zinc-400">Humidity</p>
            </div>
            <div>
                <p className="font-bold">Good</p>
                <p className="text-zinc-400">Air Quality</p>
            </div>
        </div>
      </div>
      
      <div className="flex bg-zinc-100 rounded-xl p-1 mb-6">
        <button className="w-1/2 py-2 rounded-lg text-black font-semibold">Room</button>
        <button className="w-1/2 py-2 rounded-lg bg-white text-black font-semibold shadow">Devices</button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {devices.map(device => (
            <DeviceCard key={device.id} device={device} onToggle={handleToggle} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
