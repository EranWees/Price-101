import React from 'react';
import { Page } from '../types';

interface BottomNavBarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const NavButton: React.FC<{
  icon: string;
  isActive: boolean;
  onClick: () => void;
  label: string;
}> = ({ icon, isActive, onClick, label }) => {
  return (
    <button 
        onClick={onClick}
        aria-label={label}
        className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform-gpu focus:outline-none focus:ring-2 focus:ring-blue-400 ${
            isActive ? 'bg-blue-600 text-white scale-110 shadow-lg' : 'bg-transparent text-zinc-400 hover:bg-zinc-700 hover:text-white'
        }`}
    >
        <i className={`fas ${icon} text-2xl`}></i>
    </button>
  );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentPage, onNavigate }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4">
      <div className="bg-[#1C1C1E] rounded-full shadow-lg flex justify-around items-center max-w-sm mx-auto p-2">
        <NavButton
          icon="fa-home"
          label="Home"
          isActive={currentPage === Page.Home}
          onClick={() => onNavigate(Page.Home)}
        />
        <NavButton
          icon="fa-briefcase"
          label="Services"
          isActive={currentPage === Page.Services}
          onClick={() => onNavigate(Page.Services)}
        />
        <NavButton
          icon="fa-info-circle"
          label="About"
          isActive={currentPage === Page.About}
          onClick={() => onNavigate(Page.About)}
        />
        <NavButton
          icon="fa-phone-alt"
          label="Contact"
          isActive={false}
          onClick={() => window.open('https://wa.me/265997761194', '_blank')}
        />
      </div>
    </div>
  );
};

export default BottomNavBar;