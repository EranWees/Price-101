import React from 'react';
import { Page } from '../types';

interface HomePageProps {
  onNavigate: (page: Page) => void;
}

const portfolioItems = [
  { title: 'Portraits', imgSrc: 'https://i.ibb.co/Qvz8Z35h/IMG-9619.jpg' },
  { title: 'Couples', imgSrc: 'https://i.ibb.co/2ZCM2Vn/IMG-9694.jpg' },
  { title: 'Lifestyle', imgSrc: 'https://i.ibb.co/L6Vd35d/IMG-9706.jpg' },
  { title: 'Events', imgSrc: 'https://i.ibb.co/4RJchNvW/IMG-3622.jpg' },
];

const ActionButton: React.FC<{ icon: string; title: string; onClick: () => void }> = ({ icon, title, onClick }) => (
  <button
    onClick={onClick}
    className="bg-[#1C1C1E] rounded-2xl p-4 flex items-center gap-4 w-full cursor-pointer transition-all duration-300 hover:bg-[#2C2C2E] hover:scale-105"
  >
    <div className="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center">
      <i className={`fas ${icon} text-lg text-white`}></i>
    </div>
    <div>
      <h3 className="text-md font-semibold text-gray-100 text-left">{title}</h3>
    </div>
  </button>
);


const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  return (
    <div className="w-full flex flex-col animate-fadeInUp">
      {/* Hero Section */}
      <div className="relative w-full h-[50vh] md:h-[60vh] rounded-3xl overflow-hidden">
        <img src="https://i.ibb.co/0VXyVgq4/IMG-9039.jpg" alt="Eran Studio background" className="absolute inset-0 w-full h-full object-cover"/>
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/50 to-transparent"></div>
        <div className="relative h-full flex flex-col justify-end items-start p-6 md:p-10 text-white">
          <div className="w-20 h-20 p-2 mb-4 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
            <img src="https://i.ibb.co/vvrSRLvz/Eran-logo-l.png" alt="Eran Studio Logo" className="w-full h-full object-contain"/>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Eran Studio</h1>
          <p className="text-lg md:text-xl text-gray-300 mb-6">Beautiful & Emotive Photography</p>
          <button
            onClick={() => onNavigate(Page.Services)}
            className="bg-blue-600 text-white text-lg font-bold w-full max-w-xs py-4 rounded-xl shadow-lg transition-all duration-300 hover:bg-blue-700 transform hover:scale-105 flex items-center justify-center gap-2"
          >
            Explore Services <i className="fas fa-arrow-right"></i>
          </button>
        </div>
      </div>

      {/* Content Section */}
      <div className="py-8">
        <h2 className="text-2xl font-bold mb-4">Our Work</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {portfolioItems.map((item, index) => (
            <div key={index} className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden shadow-lg group">
              <img src={item.imgSrc} alt={item.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <p className="absolute bottom-3 left-3 text-white font-bold text-lg">{item.title}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
            <ActionButton
              icon="fa-info-circle"
              title="About Our Studio"
              onClick={() => onNavigate(Page.About)}
            />
            <ActionButton
              icon="fab fa-whatsapp"
              title="Contact on WhatsApp"
              onClick={() => {
                  window.open(`https://wa.me/265997761194`, '_blank')
              }}
            />
        </div>
      </div>
    </div>
  );
};

export default HomePage;