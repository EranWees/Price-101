import React, { useMemo, useState } from 'react';
import { ReelsOrder } from '../types';

interface ReelsBookingPageProps {
  order: ReelsOrder;
  setOrder: React.Dispatch<React.SetStateAction<ReelsOrder>>;
  onComplete: () => void;
}

// Fix: Add explicit type for REELS_PRICING to help TypeScript inference
const REELS_PRICING: Record<keyof ReelsOrder, { price: number; title: string; details: string; features: string[]; bestFor: string; }> = {
  basic: { price: 15000, title: 'Basic Reel', details: '10-15s, 48hr delivery', features: ['Simple editing', 'Basic color grading', '1 revision'], bestFor: 'Quick content, outfit showcases.' },
  standard: { price: 25000, title: 'Standard Reel', details: '15-30s, 24hr delivery', features: ['Cinematic transitions', 'Advanced color grading', '2 revisions'], bestFor: 'Brand content, storytelling.' },
  premium: { price: 50000, title: 'Premium Cinematic Reel', details: '30-60s, 12hr delivery', features: ['Full cinematic edit', 'Motion graphics/text', '3 revisions'], bestFor: 'Commercials, ads, artist content.' },
};

const ReelsBookingPage: React.FC<ReelsBookingPageProps> = ({ order, setOrder, onComplete }) => {
  const [showSuccess, setShowSuccess] = useState(false);

  const total = useMemo(() => {
    let currentTotal = 0;
    if (order.basic) currentTotal += REELS_PRICING.basic.price;
    if (order.standard) currentTotal += REELS_PRICING.standard.price;
    if (order.premium) currentTotal += REELS_PRICING.premium.price;
    return currentTotal;
  }, [order]);
  
  const handleSelect = (packageName: keyof ReelsOrder) => {
    setOrder(prev => ({...prev, [packageName]: !prev[packageName]}));
  };
  
  const handleConfirm = () => {
    setShowSuccess(true);
    setTimeout(() => {
        onComplete();
    }, 1500);
  };

  const hasSelection = total > 0;

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col items-center">
      {showSuccess && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn-overlay">
            <div className="bg-[#1C1C1E] rounded-2xl p-8 flex flex-col items-center gap-4 animate-scaleIn">
              <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white text-3xl animate-checkmark-pop">
                <i className="fas fa-check"></i>
              </div>
              <p className="text-xl font-semibold text-white">Order Added!</p>
            </div>
          </div>
      )}
      <h1 className="text-3xl font-bold text-gray-100">Reels Service</h1>
      <p className="text-gray-400 mb-8">Choose the package that fits your needs</p>
      
      <div className="w-full grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* Fix: Use typed keys to avoid type errors. */}
        {(Object.keys(REELS_PRICING) as (keyof ReelsOrder)[]).map(key => {
          const pkg = REELS_PRICING[key];
          const isSelected = order[key];
          return (
            <div key={key} onClick={() => handleSelect(key)} className={`rounded-2xl p-6 shadow-lg transition-all duration-300 cursor-pointer border-2 flex flex-col ${isSelected ? 'bg-blue-600 border-blue-500' : 'bg-[#1C1C1E] border-transparent hover:bg-[#2C2C2E]'}`}>
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-bold">{pkg.title}</h3>
                <span className="text-xl font-bold">K{pkg.price.toLocaleString()}</span>
              </div>
              <p className={`text-sm mb-4 ${isSelected ? 'text-blue-200' : 'text-gray-400'}`}><i className="fas fa-clock mr-2"></i>{pkg.details}</p>
              <ul className="space-y-1 mb-4 text-left text-sm flex-grow">
                  {pkg.features.map((feat, i) => <li key={i}><i className={`fas fa-check mr-2 ${isSelected ? 'text-blue-200' : 'text-gray-500'}`}></i>{feat}</li>)}
              </ul>
            </div>
          );
        })}
      </div>

      {hasSelection && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900/80 backdrop-blur-sm border-t border-gray-700 flex justify-center items-center z-40 lg:hidden">
            <div className="bg-[#1C1C1E] rounded-xl p-2 w-full max-w-md flex justify-between items-center">
                <div className="font-bold text-lg pl-4">Total: K{total.toLocaleString()}</div>
                <button onClick={handleConfirm} className="px-8 py-3 rounded-xl font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors">
                    Confirm
                </button>
            </div>
        </div>
      )}

      {hasSelection && (
         <div className="w-full max-w-6xl mt-8 hidden lg:flex flex-col items-center">
            <div className="bg-[#1C1C1E] rounded-2xl p-6 flex justify-between items-center w-full max-w-sm">
                <span className="text-2xl font-bold">Total: K{total.toLocaleString()}</span>
                 <button onClick={handleConfirm} className="px-8 py-3 rounded-xl font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors text-lg">
                    Confirm Order
                </button>
            </div>
         </div>
      )}
    </div>
  );
};

export default ReelsBookingPage;