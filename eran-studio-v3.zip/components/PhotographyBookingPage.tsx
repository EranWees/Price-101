import React, { useState, useMemo, useEffect } from 'react';
import { PhotographyOrder } from '../types';

interface PhotographyBookingPageProps {
  order: PhotographyOrder;
  setOrder: React.Dispatch<React.SetStateAction<PhotographyOrder>>;
  onComplete: () => void;
}

const SESSION_FEE: Record<PhotographyOrder['peopleCount'], number> = { '1-2': 1000, '3-7': 2000 };
const PRICE_PER_PICTURE: Record<PhotographyOrder['peopleCount'], number> = { '1-2': 1800, '3-7': 2500 };
const EXPRESS_SURCHARGE: Record<keyof PhotographyOrder['expressPictures'], number> = { '24hrs': 3000, '12hrs': 4500, '6hrs': 6000 };


const STEPS = [{ number: 1, title: 'Session' }, { number: 2, title: 'Options' }, { number: 3, title: 'Summary' }];
const SLIDES = [
    { type: '1-2', img: "https://i.ibb.co/2ZCM2Vn/IMG-9694.jpg", title: "1-2 People" },
    { type: '1-2', img: "https://i.ibb.co/L6Vd35d/IMG-9706.jpg", title: "1-2 People" },
    { type: '1-2', img: "https://i.ibb.co/BC62wvs/IMG-9780.jpg", title: "1-2 People" },
    { type: '1-2', img: "https://i.ibb.co/6D0M259/IMG-9831.jpg", title: "1-2 People" },
    { type: '3-7', img: "https://i.ibb.co/4RJchNvW/IMG-3622.jpg", title: "3-7 People" },
];

const QuantityControl: React.FC<{ value: number, onIncrease: () => void, onDecrease: () => void }> = ({ value, onIncrease, onDecrease }) => (
    <div className="flex items-center gap-3">
        <button onClick={onDecrease} className="w-9 h-9 rounded-full bg-[#2C2C2E] flex items-center justify-center text-xl hover:bg-gray-600 transition-colors active:scale-95">-</button>
        <span className="text-lg font-semibold w-8 text-center">{value}</span>
        <button onClick={onIncrease} className="w-9 h-9 rounded-full bg-[#2C2C2E] flex items-center justify-center text-xl hover:bg-gray-600 transition-colors active:scale-95">+</button>
    </div>
);


const PhotographyBookingPage: React.FC<PhotographyBookingPageProps> = ({ order, setOrder, onComplete }) => {
    const [currentStep, setCurrentStep] = useState(1);
    const [slideIndex, setSlideIndex] = useState(SLIDES.findIndex(s => s.type === order.peopleCount));
    const [showSuccess, setShowSuccess] = useState(false);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    
    const total = useMemo(() => {
        // FIX: Provide an initial value to `reduce` to ensure `totalPictures` is calculated correctly as a number.
        const totalPictures = order.normalPictures + Object.values(order.expressPictures).reduce((a: number, b: number) => a + b, 0);
        if (totalPictures === 0) return 0;

        const sessionFee = SESSION_FEE[order.peopleCount];
        const pricePerPicture = PRICE_PER_PICTURE[order.peopleCount];
        const picturesTotal = totalPictures * pricePerPicture;

        const expressSurchargeTotal = (Object.keys(order.expressPictures) as Array<keyof typeof order.expressPictures>)
            // FIX: Provide an initial value and a typed accumulator to `reduce` to ensure correct calculation and type inference.
            .reduce((acc: number, key) => acc + order.expressPictures[key] * EXPRESS_SURCHARGE[key], 0);

        return sessionFee + picturesTotal + expressSurchargeTotal;
    }, [order]);

    useEffect(() => {
        setOrder(prev => ({...prev, peopleCount: SLIDES[slideIndex].type as '1-2' | '3-7' }));
    }, [slideIndex, setOrder]);
    
    const handleConfirm = () => {
        setShowConfirmModal(false);
        if (total <= 0) {
            onComplete();
            return;
        }
        setShowSuccess(true);
        setTimeout(() => {
            onComplete();
        }, 1500);
    };

    const renderStepContent = () => {
        switch (currentStep) {
            case 1:
                return <>
                    <div className="w-full aspect-[4/3] rounded-2xl overflow-hidden relative bg-[#1C1C1E]">
                       <div className="flex h-full transition-transform duration-500 ease-in-out" style={{ transform: `translateX(-${slideIndex * 100}%)` }}>
                            {SLIDES.map((slide, i) => (
                                <img key={i} src={slide.img} alt={slide.title} className="w-full h-full object-cover flex-shrink-0" draggable="false"/>
                            ))}
                        </div>
                    </div>
                    <div className="text-center mt-4">
                        <h3 className="text-xl font-bold">{SLIDES[slideIndex].title}</h3>
                        <p className="text-gray-400 mt-1">Session Fee: K{SESSION_FEE[SLIDES[slideIndex].type as '1-2' | '3-7'].toLocaleString()}</p>
                    </div>
                    <div className="flex justify-center gap-2 mt-4">
                        {SLIDES.map((_, i) => <button key={i} onClick={() => setSlideIndex(i)} className={`w-2.5 h-2.5 rounded-full transition-all ${slideIndex === i ? 'bg-white' : 'bg-gray-600 hover:bg-gray-500'}`}></button>)}
                    </div>
                </>;
            case 2:
                const expressOptions: { key: keyof PhotographyOrder['expressPictures'], label: string, icon: string }[] = [
                    { key: '24hrs', label: '24hrs Delivery', icon: 'fa-clock' },
                    { key: '12hrs', label: '12hrs Delivery', icon: 'fa-stopwatch' },
                    { key: '6hrs', label: '6hrs Delivery', icon: 'fa-running' },
                ];
                return <div className="space-y-4">
                    <div className="bg-[#1C1C1E] rounded-2xl p-5">
                        <div className="flex justify-between items-center">
                            <div>
                                <h3 className="font-semibold text-lg">Normal Pictures</h3>
                                <span className="text-sm text-gray-400">K{PRICE_PER_PICTURE[order.peopleCount].toLocaleString()} per photo</span>
                            </div>
                            <QuantityControl value={order.normalPictures} onIncrease={() => setOrder(p => ({...p, normalPictures: p.normalPictures + 1}))} onDecrease={() => setOrder(p => ({...p, normalPictures: Math.max(0, p.normalPictures - 1)}))} />
                        </div>
                    </div>
                    <div className="bg-[#1C1C1E] rounded-2xl p-5">
                        <h3 className="font-semibold text-lg mb-4">Express Service</h3>
                        <div className="space-y-4">
                            {expressOptions.map(opt => (
                                <div key={opt.key} className="flex justify-between items-center">
                                    <div>
                                        <i className={`fas ${opt.icon} mr-3 text-blue-400 w-5 text-center`}></i>
                                        <span className="font-semibold">{opt.label}</span>
                                        <span className="text-sm text-gray-400 ml-2">(+K{EXPRESS_SURCHARGE[opt.key].toLocaleString()} / photo)</span>
                                    </div>
                                    <QuantityControl 
                                        value={order.expressPictures[opt.key]} 
                                        onIncrease={() => setOrder(p => ({...p, expressPictures: {...p.expressPictures, [opt.key]: p.expressPictures[opt.key] + 1 }}))} 
                                        onDecrease={() => setOrder(p => ({...p, expressPictures: {...p.expressPictures, [opt.key]: Math.max(0, p.expressPictures[opt.key] - 1) }}))} 
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>;
            case 3:
                // FIX: Provide an initial value to `reduce` to ensure `totalPictures` is calculated correctly as a number.
                const totalPictures = order.normalPictures + Object.values(order.expressPictures).reduce((a: number, b: number) => a + b, 0);

                if (totalPictures === 0) {
                    return (
                        <div className="bg-[#1C1C1E] rounded-2xl p-6 text-center text-gray-400">
                            <h3 className="text-xl font-bold text-white mb-4">Order Summary</h3>
                            <p>Your summary will appear here once you select your pictures.</p>
                        </div>
                    );
                }
                
                const sessionFee = SESSION_FEE[order.peopleCount];
                const pricePerPicture = PRICE_PER_PICTURE[order.peopleCount];
                const picturesTotal = totalPictures * pricePerPicture;
                const expressSurchargeTotal = (Object.keys(order.expressPictures) as Array<keyof typeof order.expressPictures>)
                    // FIX: Provide an initial value and a typed accumulator to `reduce` to ensure correct calculation and type inference.
                    .reduce((acc: number, key) => acc + order.expressPictures[key] * EXPRESS_SURCHARGE[key], 0);
                
                return <div className="bg-[#1C1C1E] rounded-2xl p-6">
                    <h3 className="text-xl font-bold text-center mb-4">Order Summary</h3>
                    <div className="space-y-3 text-gray-300">
                         <div className="flex justify-between">
                            <span>Session Fee ({order.peopleCount} People)</span>
                            <span className="font-semibold">K{sessionFee.toLocaleString()}</span>
                         </div>
                         <div className="flex justify-between">
                            <span>{totalPictures} Pictures (@ K{pricePerPicture.toLocaleString()})</span>
                            <span className="font-semibold">K{picturesTotal.toLocaleString()}</span>
                         </div>
                         {expressSurchargeTotal > 0 && 
                            <div className="flex justify-between">
                                <span>Express Surcharges</span>
                                <span className="font-semibold">K{expressSurchargeTotal.toLocaleString()}</span>
                            </div>
                         }
                         {(Object.keys(order.expressPictures) as Array<keyof typeof order.expressPictures>).map(key => (
                            order.expressPictures[key] > 0 && (
                                <div key={key} className="flex justify-between text-sm pl-4 text-gray-400">
                                    <span>- {key} Express ({order.expressPictures[key]})</span>
                                    <span>K{(order.expressPictures[key] * EXPRESS_SURCHARGE[key]).toLocaleString()}</span>
                                </div>
                            )
                         ))}
                    </div>
                    <div className="flex justify-between text-xl font-bold mt-4 pt-4 border-t-2 border-gray-700">
                        <span>Grand Total:</span><span>K{total.toLocaleString()}</span>
                    </div>
                </div>;
        }
    };
    
    return (
        <div className="w-full max-w-md flex flex-col items-center pb-24">
            {showConfirmModal && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[60] animate-fadeIn-overlay">
                  <div className="bg-[#1C1C1E] rounded-2xl p-8 flex flex-col items-center gap-6 animate-scaleIn w-full max-w-sm mx-4">
                    <h2 className="text-xl font-bold text-white text-center">Final Confirmation</h2>
                    <p className="text-gray-300 text-center">Add this photography package to your quote?</p>
                    <div className="flex justify-between w-full gap-4">
                        <button 
                            onClick={() => setShowConfirmModal(false)}
                            className="w-full px-6 py-3 rounded-xl font-semibold bg-[#2C2C2E] hover:bg-gray-600 transition-colors"
                        >
                            Go Back
                        </button>
                        <button 
                            onClick={handleConfirm}
                            className="w-full px-8 py-3 rounded-xl font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                        >
                            Yes, Add
                        </button>
                    </div>
                  </div>
                </div>
            )}
            {showSuccess && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn-overlay">
                  <div className="bg-[#1C1C1E] rounded-2xl p-8 flex flex-col items-center gap-4 animate-scaleIn">
                    <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center text-white text-3xl animate-checkmark-pop">
                      <i className="fas fa-check"></i>
                    </div>
                    <p className="text-xl font-semibold text-white">Order Added!</p>
                  </div>
                </div>
            )}
            <h1 className="text-3xl font-bold text-gray-100">Photography</h1>
            <p className="text-gray-400 mb-6">Customize your session</p>
            <div className="w-full bg-[#1C1C1E] p-1 rounded-xl flex justify-between gap-1 mb-6">
                {STEPS.map(({ number, title }) => <button key={number} onClick={() => setCurrentStep(number)} className={`w-full py-2 rounded-lg font-semibold transition-colors text-sm ${currentStep === number ? 'bg-gray-600 text-white' : 'text-gray-400 hover:bg-[#2C2C2E]'}`}>{title}</button>)}
            </div>
            <div className="w-full min-h-[400px]">{renderStepContent()}</div>
            <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#1C1C1E]/80 backdrop-blur-sm border-t border-gray-700 flex justify-between items-center z-40">
                <div className="font-bold text-lg">Total: K{total.toLocaleString()}</div>
                <div className="flex items-center gap-3">
                    {currentStep > 1 && <button onClick={() => setCurrentStep(s => s - 1)} className="px-6 py-3 rounded-xl font-semibold bg-[#2C2C2E] hover:bg-gray-600 transition-colors">Back</button>}
                    <button onClick={currentStep === 3 ? () => setShowConfirmModal(true) : () => setCurrentStep(s => s + 1)} className="px-8 py-3 rounded-xl font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors">
                        {currentStep === 3 ? 'Confirm' : 'Next'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PhotographyBookingPage;
