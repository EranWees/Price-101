import React from 'react';
import { Page } from '../types';

interface WelcomePageProps {
  onNavigate: (page: Page) => void;
}

const WelcomePage: React.FC<WelcomePageProps> = ({ onNavigate }) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center text-center p-4 animate-fadeIn">
      <div className="w-32 h-32 p-3 bg-gray-800 rounded-full flex items-center justify-center shadow-2xl mb-6">
        <img 
          src="https://i.ibb.co/vvrSRLvz/Eran-logo-l.png" 
          alt="Eran Studio Logo" 
          className="w-full h-full object-contain"
        />
      </div>
      <h1 className="text-4xl font-bold text-white tracking-wider mb-2">
        Eran Studio
      </h1>
      <p className="text-lg text-gray-400 mb-10">
        Beautiful & Emotive
      </p>
      
      <button
        onClick={() => onNavigate(Page.Home)}
        className="bg-blue-600 text-white text-lg font-semibold w-full max-w-xs py-4 rounded-xl shadow-lg transition-all duration-300 hover:bg-blue-700 hover:shadow-blue-500/30 transform hover:scale-105"
      >
        Enter Studio
      </button>
    </div>
  );
};

export default WelcomePage;