import React, { useState } from 'react';

interface SmartLightPageProps {
  onBack: () => void;
}

const watts = ['8 watt', '9 watt', '12.5 watt', '17 watt'];
const modes = [
    { name: 'Auto', icon: 'fa-magic' },
    { name: 'Cool', icon: 'fa-snowflake' },
    { name: 'Day', icon: 'fa-sun' },
    { name: 'Night', icon: 'fa-moon' },
];

const SmartLightPage: React.FC<SmartLightPageProps> = ({ onBack }) => {
    const [activeWatt, setActiveWatt] = useState('8 watt');
    const [activeMode, setActiveMode] = useState('Auto');
    const [intensity] = useState(80); // from 0 to 100

    // SVG arc calculation for a 270 degree arc starting from 135 degrees
    const radius = 90;
    const circumference = 2 * Math.PI * radius;
    const arcLength = circumference * (270 / 360);
    const progress = (intensity / 100) * arcLength;

  return (
    <div className="p-6 pb-24 h-full flex flex-col">
      <header className="flex justify-between items-center mb-6">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center">
            <i className="fas fa-chevron-left"></i>
        </button>
        <h1 className="text-xl font-bold">Smart Light</h1>
        <button className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center">
            <i className="fas fa-ellipsis-h"></i>
        </button>
      </header>

      <div className="flex bg-zinc-100 rounded-xl p-1 mb-8">
        {watts.map(watt => (
            <button key={watt} onClick={() => setActiveWatt(watt)} className={`w-1/4 py-2 rounded-lg text-sm font-semibold transition-all ${activeWatt === watt ? 'bg-black text-white' : 'text-zinc-500'}`}>{watt}</button>
        ))}
      </div>

      <div className="flex-grow flex flex-col items-center">
        <p className="text-zinc-500 mb-2">Controller</p>
        <div className="relative w-64 h-64 flex items-center justify-center">
            <svg className="absolute w-full h-full" viewBox="0 0 200 200" transform="rotate(0)">
                <circle cx="100" cy="100" r={radius} fill="none" stroke="#f0f0f0" strokeWidth="16" strokeLinecap="round" pathLength={arcLength} strokeDasharray={arcLength} strokeDashoffset={0} transform="rotate(135 100 100)" />
                <circle cx="100" cy="100" r={radius} fill="none" stroke="#007aff" strokeWidth="16" strokeLinecap="round" pathLength={arcLength} strokeDasharray={`${progress} ${arcLength - progress}`} strokeDashoffset={0} transform="rotate(135 100 100)" />
            </svg>
            <div className="text-center z-10">
                <p className="text-5xl font-bold">{intensity}%</p>
                <p className="text-zinc-500">light intensity</p>
            </div>
             <div className="absolute w-full flex justify-between bottom-8 px-4 text-sm text-zinc-500">
                <span>Min</span>
                <span>Max</span>
            </div>
        </div>

        <div className="grid grid-cols-4 gap-4 w-full mt-4">
            {modes.map(mode => (
                 <div key={mode.name} onClick={() => setActiveMode(mode.name)} className={`p-3 rounded-2xl text-center cursor-pointer transition-colors ${activeMode === mode.name ? 'bg-black text-white' : 'bg-zinc-100 text-black'}`}>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-2 bg-white">
                        <i className={`fas ${mode.icon} text-black text-xl`}></i>
                    </div>
                    <p className="text-sm font-semibold">{mode.name}</p>
                </div>
            ))}
        </div>
      </div>
      
      <div className="bg-zinc-100 rounded-3xl p-5 mt-8">
        <p className="font-bold mb-1">Power consumption</p>
        <p className="text-sm text-zinc-500 mb-4">8 Watt Smart Light</p>
        <div className="flex justify-around text-center">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center"><i className="fas fa-bolt"></i></div>
                <div>
                    <p className="font-bold">5kWh</p>
                    <p className="text-sm text-zinc-500">Today</p>
                </div>
            </div>
             <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center"><i className="fas fa-plug"></i></div>
                <div>
                    <p className="font-bold">120kWh</p>
                    <p className="text-sm text-zinc-500">This month</p>
                </div>
            </div>
        </div>
      </div>

      <button className="w-full bg-black text-white font-bold py-4 rounded-2xl mt-6">Add new device</button>
    </div>
  );
};

export default SmartLightPage;
