import React, { useMemo } from 'react';
import { Page, PhotographyOrder, ReelsOrder, PortraitsOrder } from '../types';

interface ServicesPageProps {
  onNavigate: (page: Page) => void;
  completedServices: string[];
  orders: {
    photographyOrder: PhotographyOrder;
    reelsOrder: ReelsOrder;
    portraitsOrder: PortraitsOrder;
  }
}

const SESSION_FEE = { '1-2': 1000, '3-7': 2000 };
const PRICE_PER_PICTURE = { '1-2': 1800, '3-7': 2500 };
const EXPRESS_SURCHARGE = { '24hrs': 3000, '12hrs': 4500, '6hrs': 6000 };
const REELS_PRICING = { basic: 15000, standard: 25000, premium: 50000 };
const PORTRAITS_PRICING = { a3: 20000, a2: 25000, a1: 35000, a0: 65000 };

const ServiceCard: React.FC<{ icon: string; title: string; description: string; imgSrc: string; onClick: () => void; isSelected: boolean; style?: React.CSSProperties }> = ({ icon, title, description, imgSrc, onClick, isSelected, style }) => (
  <div
    onClick={onClick}
    className={`relative rounded-3xl w-full h-40 max-w-md cursor-pointer transition-all duration-300 overflow-hidden shadow-lg ${isSelected ? 'ring-4 ring-blue-500' : 'ring-2 ring-transparent hover:ring-2 hover:ring-gray-600'}`}
    style={style}
  >
    <img src={imgSrc} alt={title} className="absolute inset-0 w-full h-full object-cover" />
    <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/20"></div>
    <div className="relative h-full flex flex-col justify-end p-6 text-white">
        <div className="flex items-center gap-4 mb-2">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-600' : 'bg-white/10'}`}>
                <i className={`fas ${icon} text-2xl`}></i>
            </div>
            <h3 className="text-2xl font-bold">{title}</h3>
        </div>
        <p className={`text-sm transition-colors text-white/80`}>{description}</p>
    </div>
    {isSelected && (
      <div className="absolute top-4 right-4 text-white bg-blue-600 rounded-full w-8 h-8 flex items-center justify-center">
        <i className="fas fa-check"></i>
      </div>
    )}
  </div>
);

const services = [
    { page: Page.Photography, key: 'photography', icon: 'fa-camera', title: 'Photography', description: 'Professional photo sessions', imgSrc: 'https://i.ibb.co/2ZCM2Vn/IMG-9694.jpg' },
    { page: Page.Reels, key: 'reels', icon: 'fa-film', title: 'Reels', description: 'Creative video content', imgSrc: 'https://i.ibb.co/0VXyVgq4/IMG-9039.jpg' },
    { page: Page.Portraits, key: 'portraits', icon: 'fa-palette', title: 'Portraits (Canvas)', description: 'Beautiful portrait artwork', imgSrc: 'https://i.ibb.co/Qvz8Z35h/IMG-9619.jpg' },
];

const ServicesPage: React.FC<ServicesPageProps> = ({ onNavigate, completedServices, orders }) => {
  const calculateTotals = useMemo(() => {
    let photographyTotal = 0;
    const { photographyOrder, reelsOrder, portraitsOrder } = orders;
    
    if (completedServices.includes('photography')) {
      const { peopleCount, normalPictures, expressPictures } = photographyOrder;
      // FIX: Add explicit types to reduce function to prevent `totalPictures` calculation from failing.
      const totalPictures = normalPictures + Object.values(expressPictures).reduce((a: number, b: number) => a + b, 0);

      if (totalPictures > 0) {
          const sessionFee = SESSION_FEE[peopleCount];
          const pricePerPicture = PRICE_PER_PICTURE[peopleCount];
          const picturesTotal = totalPictures * pricePerPicture;

          const expressSurchargeTotal = 
              expressPictures['24hrs'] * EXPRESS_SURCHARGE['24hrs'] +
              expressPictures['12hrs'] * EXPRESS_SURCHARGE['12hrs'] +
              expressPictures['6hrs'] * EXPRESS_SURCHARGE['6hrs'];
          
          photographyTotal = sessionFee + picturesTotal + expressSurchargeTotal;
      }
    }

    let reelsTotal = 0;
    if (completedServices.includes('reels')) {
      if (reelsOrder.basic) reelsTotal += REELS_PRICING.basic;
      if (reelsOrder.standard) reelsTotal += REELS_PRICING.standard;
      if (reelsOrder.premium) reelsTotal += REELS_PRICING.premium;
    }

    let portraitsTotal = 0;
    if (completedServices.includes('portraits')) {
      portraitsTotal += portraitsOrder.a3.quantity * PORTRAITS_PRICING.a3;
      portraitsTotal += portraitsOrder.a2.quantity * PORTRAITS_PRICING.a2;
      portraitsTotal += portraitsOrder.a1.quantity * PORTRAITS_PRICING.a1;
      portraitsTotal += portraitsOrder.a0.quantity * PORTRAITS_PRICING.a0;
    }
    
    const grandTotal = photographyTotal + reelsTotal + portraitsTotal;
    return { photographyTotal, reelsTotal, portraitsTotal, grandTotal };
  }, [completedServices, orders]);

  const { photographyTotal, reelsTotal, portraitsTotal, grandTotal } = calculateTotals;

  const generateWhatsAppMessage = () => {
    let message = `Hello Eran Studio! I'm interested in multiple services.%0A%0A*Complete Order Details:*%0A%0A`;
    if (grandTotal === 0) {
        return `Hello Eran Studio! I'm interested in your services.`;
    }

    if (photographyTotal > 0) {
      const { peopleCount, normalPictures, expressPictures } = orders.photographyOrder;
      // FIX: Add explicit types to reduce function to prevent `totalPictures` calculation from failing.
      const totalPictures = normalPictures + Object.values(expressPictures).reduce((a: number, b: number) => a + b, 0);
      const sessionFee = SESSION_FEE[peopleCount];
      const pricePerPicture = PRICE_PER_PICTURE[peopleCount];
      const expressSurchargeTotal =
          expressPictures['24hrs'] * EXPRESS_SURCHARGE['24hrs'] +
          expressPictures['12hrs'] * EXPRESS_SURCHARGE['12hrs'] +
          expressPictures['6hrs'] * EXPRESS_SURCHARGE['6hrs'];
      
      message += `*Photography (${peopleCount} People):*%0A`;
      message += `- Session Fee: K${sessionFee.toLocaleString()}%0A`;
      message += `- ${totalPictures} Pictures (@ K${pricePerPicture.toLocaleString()}): K${(totalPictures * pricePerPicture).toLocaleString()}%0A`;
      
      if (expressSurchargeTotal > 0) {
          message += `- Express Surcharges: K${expressSurchargeTotal.toLocaleString()}%0A`;
          if (expressPictures['24hrs'] > 0) {
              message += `  - 24hrs (${expressPictures['24hrs']}): K${(expressPictures['24hrs'] * EXPRESS_SURCHARGE['24hrs']).toLocaleString()}%0A`;
          }
          if (expressPictures['12hrs'] > 0) {
              message += `  - 12hrs (${expressPictures['12hrs']}): K${(expressPictures['12hrs'] * EXPRESS_SURCHARGE['12hrs']).toLocaleString()}%0A`;
          }
          if (expressPictures['6hrs'] > 0) {
              message += `  - 6hrs (${expressPictures['6hrs']}): K${(expressPictures['6hrs'] * EXPRESS_SURCHARGE['6hrs']).toLocaleString()}%0A`;
          }
      }
      
      message += `Subtotal: K${photographyTotal.toLocaleString()}%0A%0A`;
    }

    if (reelsTotal > 0) {
      message += `*Reels:*%0A`;
      if (orders.reelsOrder.basic) message += `- Basic Reel: K${REELS_PRICING.basic.toLocaleString()}%0A`;
      if (orders.reelsOrder.standard) message += `- Standard Reel: K${REELS_PRICING.standard.toLocaleString()}%0A`;
      if (orders.reelsOrder.premium) message += `- Premium Reel: K${REELS_PRICING.premium.toLocaleString()}%0A`;
      message += `Subtotal: K${reelsTotal.toLocaleString()}%0A%0A`;
    }

    if (portraitsTotal > 0) {
      message += `*Portraits:*%0A`;
      const { a3, a2, a1, a0 } = orders.portraitsOrder;
      if (a3.quantity > 0) message += `- ${a3.quantity} A3 Canvas: K${(a3.quantity * PORTRAITS_PRICING.a3).toLocaleString()}%0A`;
      if (a2.quantity > 0) message += `- ${a2.quantity} A2 Canvas: K${(a2.quantity * PORTRAITS_PRICING.a2).toLocaleString()}%0A`;
      if (a1.quantity > 0) message += `- ${a1.quantity} A1 Canvas: K${(a1.quantity * PORTRAITS_PRICING.a1).toLocaleString()}%0A`;
      if (a0.quantity > 0) message += `- ${a0.quantity} A0 Canvas: K${(a0.quantity * PORTRAITS_PRICING.a0).toLocaleString()}%0A`;
      message += `Subtotal: K${portraitsTotal.toLocaleString()}%0A%0A`;
    }
    
    message += `*Grand Total: K${grandTotal.toLocaleString()}*%0A%0A`;
    message += `Please let me know the next steps to book these services.`;
    return message;
  };

  const sendOverallQuote = () => {
    const message = generateWhatsAppMessage();
    window.open(`https://wa.me/265997761194?text=${message}`, '_blank');
  };
  
  return (
    <div className="w-full">
      <div className="text-left w-full mb-8">
        <h1 className="text-3xl font-bold text-gray-100">Our Services</h1>
        <p className="text-gray-400">Tap a service to customize your quote.</p>
      </div>
      
      <div className="flex flex-col lg:flex-row lg:items-start gap-8">
        <div className="w-full lg:flex-1 flex flex-col gap-5">
            {services.map((service, index) => (
            <ServiceCard
                key={service.key}
                icon={service.icon}
                title={service.title}
                description={service.description}
                imgSrc={service.imgSrc}
                onClick={() => onNavigate(service.page)}
                isSelected={completedServices.includes(service.key)}
                style={{ animation: `fadeInUp 0.5s ${index * 100}ms ease-out forwards`, opacity: 0 }}
            />
            ))}
        </div>

        <div className="w-full lg:w-2/5 lg:sticky lg:top-8">
            {completedServices.length > 0 && (
            <div className="w-full animate-fadeInUp" style={{animationDelay: '300ms', opacity: 0}}>
                <div className="bg-[#1C1C1E] rounded-3xl p-6 shadow-lg text-left">
                <h2 className="text-2xl font-bold text-white mb-5 text-center">Quote Summary</h2>
                <div className="space-y-4">
                    {photographyTotal > 0 && <div className="flex justify-between items-center text-gray-300"><span><i className="fas fa-camera mr-3 text-blue-400"></i>Photography</span><span className="font-semibold">K{photographyTotal.toLocaleString()}</span></div>}
                    {reelsTotal > 0 && <div className="flex justify-between items-center text-gray-300"><span><i className="fas fa-film mr-3 text-blue-400"></i>Reels</span><span className="font-semibold">K{reelsTotal.toLocaleString()}</span></div>}
                    {portraitsTotal > 0 && <div className="flex justify-between items-center text-gray-300"><span><i className="fas fa-palette mr-3 text-blue-400"></i>Portraits</span><span className="font-semibold">K{portraitsTotal.toLocaleString()}</span></div>}
                </div>
                <div className="flex justify-between mt-6 text-xl font-bold border-t-2 border-gray-700 pt-4">
                    <span>Total:</span>
                    <span>K{grandTotal.toLocaleString()}</span>
                </div>
                <button 
                    onClick={sendOverallQuote}
                    className="w-full mt-6 bg-blue-600 text-white font-bold py-4 px-4 rounded-xl flex items-center justify-center gap-3 hover:bg-blue-700 transition-all text-lg transform hover:scale-105"
                >
                    <i className="fab fa-whatsapp text-2xl"></i> Send Quote
                </button>
                </div>
            </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;